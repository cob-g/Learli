learli brand kit 2.0
====================

logos/svg        Vector logo files. Use these wherever you can.
logos/png        The same logos as transparent PNGs (wordmark 1632 px wide, icon 1024 px).
boards/png       The nine guideline boards as images (2560 x 1600).
boards/learli-brand-guidelines.pdf
                 All nine boards in one PDF, one board per page.
boards/html      The boards as plain web pages. Open any of them in a browser.
                 They load the fonts from Google Fonts, so they need a connection.
tokens           Colors, type scale, spacing and radii as JSON and CSS variables.
canvas-source    The editable canvas files the boards were exported from.

Fonts (free, SIL Open Font License)
  Lexend    https://fonts.google.com/specimen/Lexend
  Literata  https://fonts.google.com/specimen/Literata

Still to fill in
  - Photography. The frames marked [PHOTO] are briefs, not images.
  - Print colors. Pantone and CMYK values need matching with your printer.
  - [MOBILE NUMBER] on the business card.
